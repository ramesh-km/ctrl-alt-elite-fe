package com.ctrl_alt_elite.proxy_user_bank_application.entity;

public enum ERole {
  ROLE_USER,
  ROLE_MODERATOR,
  ROLE_ADMIN
}
