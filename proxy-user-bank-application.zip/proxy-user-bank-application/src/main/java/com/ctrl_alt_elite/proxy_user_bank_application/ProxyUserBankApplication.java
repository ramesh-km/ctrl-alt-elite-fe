package com.ctrl_alt_elite.proxy_user_bank_application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProxyUserBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProxyUserBankApplication.class, args);
	}

}
