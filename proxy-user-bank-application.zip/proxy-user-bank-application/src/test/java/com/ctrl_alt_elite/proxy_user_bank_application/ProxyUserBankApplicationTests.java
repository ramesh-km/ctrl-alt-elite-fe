package com.ctrl_alt_elite.proxy_user_bank_application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyUserBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
